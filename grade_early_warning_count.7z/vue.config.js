module.exports = { 
  // project deployment base
  publicPath: '',  
  // where to output built files
  outputDir: 'dist',
  // where to put static assets (js/css/img/font/...)
  assetsDir: 'grade_early_warning_count/tools',//assetsDir: 'swap-attachment',
  // filename for index.html (relative to outputDir)
  indexPath: 'grade_early_warning_count.php',
}